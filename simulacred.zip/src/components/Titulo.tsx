function Titulo(props:any) {
  return (
    <div className=' text-xl font-sans font-semibold text-sky-900'>{props.name}</div>
  )
}

export default Titulo