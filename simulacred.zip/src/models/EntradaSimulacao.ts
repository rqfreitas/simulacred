export interface EntradaSimulacao {
  valorDesejado: number;
  prazo: number;
}